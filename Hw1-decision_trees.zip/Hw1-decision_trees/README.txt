!!!***THE PROGRAM IS WRITTEN AND EXECUTED IN PYTHON 3***!!!

1. Make sure to add 'hw1.train.col', 'hw1.test.col', and 'hw1.dev.dev' files in the same folder that this code is in.

2. Run the 'SamuelMirakov.py' file in a Python IDE (terminal can also be used)

3. To change the depth limit of the tree, to see the learning curves, or to simply print out the trees of any depth; simply read the comments in the code.

This program creates a decision tree from the Train file, and uses a 60-word Bag-of-Words method that will find those exact words in sentences of the training file, the original entropy, and entropy of feature is found and a tree is created. Then using the Test file, the accuracy of the predictions will be found and outputted.


- Samuel Mirakov    